Written by Mark Chua

Comments with *** at the beginning are line of codes than can only be finished if another group member's code is finished.
These can be found easily using ctrl + f and search ***

Most if-statements are just place holders and may be fill out or removed.