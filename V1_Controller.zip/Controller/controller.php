<?php 
//Written by Mark Chua

//***require(DATABASE_NAME)

if ($action == 'list_restaurant') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'details_restaurant') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'add_restaurant') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'delete_restaurant') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'list_menu') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE	
}

if ($action == 'add_food') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'delete_food') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'postReview') {
    $name = filter_input(INPUT_POST, 'name');
    $email = filter_input(INPUT_POST, 'email');
    $restaurant = filter_input(INPUT_POST, 'restaurant');
    $dish = filter_input(INPUT_POST, 'dish');
    $review = filter_input(INPUT_POST, 'review');
    $filename = filter_input(INPUT_POST, 'filename');

      //validate inputs
      if ($category_id == NULL || $category_id == FALSE || $code == NULL || 
          $name == NULL || $price == NULL || $price == FALSE) {
              $error = "Invalid product data. Check all fields and try again.";
              include('../errors/error.php'); //***error page location
          } else { 
              //***function name to add review
              FUNCTION_POST_REVIEW($name, $email, $restaurant, $dish, $review, $filename); 
}

if ($action == 'edit_review') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'add_user') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}

if ($action == 'edit_user') {
//$VARIABLE = filter_input(INPUT_POST, 'NAME', 
            //FILTER_VALIDATE_INT); <---//FILTER TYPE
}


 ?>

 