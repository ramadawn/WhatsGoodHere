<?php //include UI header here?>
<main>
    <h1>Database Error</h1>
    <p>There was an error connecting to the database.</p>
    <p>Error message: <?php echo $error_message; ?></p>
</main>
<?php // include ui footer here?>
