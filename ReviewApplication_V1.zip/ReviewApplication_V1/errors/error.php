<?php //include header ?>


<div>
    <h1 >Error</h1>
    <p><?php echo $error; ?></p>
</div>
<?php //include footer ?>