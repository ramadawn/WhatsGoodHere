
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
         
         
         
         /*
         
          verify login password by recalling the account by email
          * and then use the returned object's password to compare with regular password 
          * and hashed database password by using password_verify('regular password', $user->getpassword();
          * 
         $user = new User_Account();
         
         
         $password = 'christine3135';
         
         
          $hash = password_hash($password, PASSWORD_BCRYPT);
          
           
          if (password_verify($password,$user->getPassword())) {
            echo "Let me in, I'm genuine!";
            echo $user->getPassword();
          }
         */
        ?>
    </body>
</html>
